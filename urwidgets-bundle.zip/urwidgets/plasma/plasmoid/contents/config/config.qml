import QtQuick 2.15
import org.kde.plasma.configuration 2.0

ConfigModel {
    ConfigCategory {
        name: i18n("Global Theme & Widget Preferences")
        icon: "preferences-desktop-theme"
        source: "configGeneral.qml"
    }
}
